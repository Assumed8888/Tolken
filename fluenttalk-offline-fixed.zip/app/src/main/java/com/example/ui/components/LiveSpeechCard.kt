package com.example.ui.components

import java.util.Locale
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.engine.SpeakerSource
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.IndigoPrimaryLight
import com.example.ui.theme.TealAccent

@Composable
fun LiveSpeechCard(
    isListening: Boolean,
    liveDanishPartial: String,
    liveRussianLatest: String,
    micRmsDb: Float,
    interlocutorRmsDb: Float = 0f,
    userRmsDb: Float = 0f,
    isInterlocutorSpeaking: Boolean = false,
    isUserSpeaking: Boolean = false,
    isAppHearingSound: Boolean = false,
    speakerSource: SpeakerSource = SpeakerSource.SILENCE,
    ownVoiceThresholdDb: Float = 10.0f,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("live_speech_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Master Sound Status & Acoustic Presence Bar
            MasterSoundStatusHeader(
                isListening = isListening,
                isAppHearingSound = isAppHearingSound,
                micRmsDb = micRmsDb
            )

            Spacer(modifier = Modifier.height(12.dp))

            // DUAL VOICE ACOUSTIC INDICATORS (Собеседник vs Мой голос)
            DualVoiceAcousticIndicators(
                isListening = isListening,
                interlocutorRmsDb = interlocutorRmsDb,
                userRmsDb = userRmsDb,
                isInterlocutorSpeaking = isInterlocutorSpeaking,
                isUserSpeaking = isUserSpeaking,
                speakerSource = speakerSource,
                ownVoiceThresholdDb = ownVoiceThresholdDb
            )

            Spacer(modifier = Modifier.height(14.dp))

            // DANISH INPUT SECTION (da-DK from Video / Interlocutor)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (isInterlocutorSpeaking || (isListening && interlocutorRmsDb > 0.5f))
                            EmeraldSuccess.copy(alpha = 0.09f)
                        else
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                    )
                    .border(
                        width = 1.dp,
                        color = if (isInterlocutorSpeaking || (isListening && interlocutorRmsDb > 0.5f))
                            EmeraldSuccess.copy(alpha = 0.35f)
                        else
                            Color.Transparent,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .padding(12.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Hearing,
                                contentDescription = "Датская речь",
                                tint = if (isInterlocutorSpeaking) EmeraldSuccess else TealAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ДАТСКИЙ (da-DK) • ВИДЕО / СОБЕСЕДНИК",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isInterlocutorSpeaking) EmeraldSuccess else TealAccent,
                                letterSpacing = 0.5.sp
                            )
                        }

                        if (isListening && (isInterlocutorSpeaking || liveDanishPartial.isNotBlank())) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(EmeraldSuccess.copy(alpha = 0.18f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "ПРИЕМ РЕЧИ",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldSuccess
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    if (liveDanishPartial.isNotBlank()) {
                        Text(
                            text = liveDanishPartial,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.testTag("live_danish_text")
                        )
                    } else {
                        Text(
                            text = if (isListening)
                                "Taler du dansk? (Слушаю датскую речь из видео или от собеседника...)"
                            else
                                "Нажмите «Начать перевод», чтобы приложение начало слушать звук",
                            style = MaterialTheme.typography.bodyMedium,
                            fontStyle = FontStyle.Italic,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // RUSSIAN OUTPUT SECTION (ru-RU synthesized into earpiece)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f))
                    .padding(12.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Русский перевод",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "РУССКИЙ (ru-RU) • ВЫВОД В НАУШНИКИ",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 0.5.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    if (liveRussianLatest.isNotBlank()) {
                        Text(
                            text = liveRussianLatest,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.testTag("live_russian_text")
                        )
                    } else {
                        Text(
                            text = "Синтез русской речи направляется в наушники...",
                            style = MaterialTheme.typography.bodyMedium,
                            fontStyle = FontStyle.Italic,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Top Master Banner indicating whether the app currently hears incoming sound.
 */
@Composable
private fun MasterSoundStatusHeader(
    isListening: Boolean,
    isAppHearingSound: Boolean,
    micRmsDb: Float
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("master_sound_indicator"),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(
                        when {
                            !isListening -> MaterialTheme.colorScheme.outline
                            isAppHearingSound -> EmeraldSuccess
                            else -> TealAccent
                        }
                    )
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = when {
                        !isListening -> "Приложение остановлено"
                        isAppHearingSound -> "Приложение слышит звук: ${String.format(Locale.getDefault(), "%.1f", micRmsDb.coerceAtLeast(0f))} dB"
                        else -> "Микрофон активен (ожидание звука)"
                    },
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = when {
                        !isListening -> MaterialTheme.colorScheme.onSurfaceVariant
                        isAppHearingSound -> EmeraldSuccess
                        else -> MaterialTheme.colorScheme.primary
                    }
                )
                Text(
                    text = if (isListening) "Непрерывный захват датской речи" else "Нажмите «Начать перевод» для захвата",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Live Audio Equalizer Waveform
        if (isListening) {
            RmsWaveform(
                rmsDb = micRmsDb,
                isUserSpeaking = false
            )
        }
    }
}

/**
 * DUAL VOICE INDICATORS:
 * 1) Interlocutor's voice (Собеседник / Датский da-DK / Видео)
 * 2) My voice (Мой голос / Владелец / ru-RU)
 */
@Composable
private fun DualVoiceAcousticIndicators(
    isListening: Boolean,
    interlocutorRmsDb: Float,
    userRmsDb: Float,
    isInterlocutorSpeaking: Boolean,
    isUserSpeaking: Boolean,
    speakerSource: SpeakerSource,
    ownVoiceThresholdDb: Float
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 1. INTERLOCUTOR VOICE CARD (Датский / Видео)
        val isInterlocutorActive = isListening && (isInterlocutorSpeaking || interlocutorRmsDb >= 0.4f)
        Card(
            modifier = Modifier
                .weight(1f)
                .testTag("interlocutor_voice_indicator"),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isInterlocutorActive)
                    EmeraldSuccess.copy(alpha = 0.12f)
                else
                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            ),
            border = if (isInterlocutorActive)
                androidx.compose.foundation.BorderStroke(1.5.dp, EmeraldSuccess.copy(alpha = 0.55f))
            else
                androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Hearing,
                            contentDescription = null,
                            tint = if (isInterlocutorActive) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Собеседник",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isInterlocutorActive) EmeraldSuccess else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Status Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                if (isInterlocutorActive) EmeraldSuccess.copy(alpha = 0.22f)
                                else MaterialTheme.colorScheme.outline.copy(alpha = 0.12f)
                            )
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (isInterlocutorActive) "СЛЫШИТ" else "ЖДЕТ",
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isInterlocutorActive) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Датская речь / Видео",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Equalizer meter & dB readout
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    VoiceEqualizerBars(
                        levelDb = interlocutorRmsDb,
                        isActive = isInterlocutorActive,
                        activeColor = EmeraldSuccess,
                        modifier = Modifier
                            .width(42.dp)
                            .height(16.dp)
                    )

                    Text(
                        text = "${String.format(Locale.getDefault(), "%.1f", interlocutorRmsDb.coerceAtLeast(0f))} dB",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isInterlocutorActive) EmeraldSuccess else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // 2. MY VOICE CARD (Владелец / RU)
        val isUserActive = isListening && (isUserSpeaking || userRmsDb >= 0.4f)
        Card(
            modifier = Modifier
                .weight(1f)
                .testTag("user_voice_indicator"),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isUserActive)
                    AmberWarning.copy(alpha = 0.14f)
                else
                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            ),
            border = if (isUserActive)
                androidx.compose.foundation.BorderStroke(1.5.dp, AmberWarning.copy(alpha = 0.55f))
            else
                androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = null,
                            tint = if (isUserActive) AmberWarning else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Мой голос",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isUserActive) AmberWarning else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Status Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                if (isUserActive) AmberWarning.copy(alpha = 0.22f)
                                else MaterialTheme.colorScheme.outline.copy(alpha = 0.12f)
                            )
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (isUserActive) "ГОЛОС" else "МОЛЧИТ",
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isUserActive) AmberWarning else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Владелец / Гарнитура",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Equalizer meter & dB readout
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    VoiceEqualizerBars(
                        levelDb = userRmsDb,
                        isActive = isUserActive,
                        activeColor = AmberWarning,
                        modifier = Modifier
                            .width(42.dp)
                            .height(16.dp)
                    )

                    Text(
                        text = "${String.format(Locale.getDefault(), "%.1f", userRmsDb.coerceAtLeast(0f))} dB",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isUserActive) AmberWarning else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

/**
 * Animated dynamic equalizer volume bars for voice indicators.
 */
@Composable
fun VoiceEqualizerBars(
    levelDb: Float,
    isActive: Boolean,
    activeColor: Color,
    modifier: Modifier = Modifier,
    barCount: Int = 5
) {
    val infiniteTransition = rememberInfiniteTransition(label = "eq_bars")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(380, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "eq_pulse"
    )

    val normalized = if (isActive) {
        ((levelDb.coerceAtLeast(0f) + 1.0f) / 12.0f).coerceIn(0.25f, 1.0f)
    } else {
        0.12f
    }

    Canvas(modifier = modifier) {
        val barWidth = 3.5.dp.toPx()
        val spacing = 3.dp.toPx()
        val canvasHeight = size.height

        for (i in 0 until barCount) {
            val dynamicScale = when (i) {
                0, 4 -> 0.45f * normalized
                1, 3 -> 0.75f * normalized * if (isActive) pulse else 1f
                else -> 1.0f * normalized * if (isActive) (0.8f + pulse * 0.2f) else 1f
            }
            val barH = (canvasHeight * dynamicScale).coerceAtLeast(3.dp.toPx())
            val x = i * (barWidth + spacing)
            val y = (canvasHeight - barH) / 2

            drawRoundRect(
                color = if (isActive) activeColor else activeColor.copy(alpha = 0.22f),
                topLeft = Offset(x, y),
                size = Size(barWidth, barH),
                cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
            )
        }
    }
}

@Composable
fun RmsWaveform(
    rmsDb: Float,
    isUserSpeaking: Boolean = false
) {
    val infiniteTransition = rememberInfiniteTransition(label = "wave")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(450, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val normalizedLevel = ((rmsDb + 2.0f) / 12.0f).coerceIn(0.15f, 1.0f)
    val barColor = if (isUserSpeaking) AmberWarning else TealAccent

    Canvas(
        modifier = Modifier
            .width(44.dp)
            .height(18.dp)
    ) {
        val barCount = 5
        val barWidth = 4.dp.toPx()
        val spacing = 4.dp.toPx()
        val canvasHeight = size.height

        for (i in 0 until barCount) {
            val factor = when (i) {
                0, 4 -> 0.45f * normalizedLevel
                1, 3 -> 0.75f * normalizedLevel * pulse
                else -> 1.0f * normalizedLevel * (0.8f + pulse * 0.2f)
            }
            val barHeight = (canvasHeight * factor).coerceAtLeast(4.dp.toPx())
            val x = i * (barWidth + spacing)
            val y = (canvasHeight - barHeight) / 2

            drawRoundRect(
                color = barColor,
                topLeft = Offset(x, y),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
            )
        }
    }
}
