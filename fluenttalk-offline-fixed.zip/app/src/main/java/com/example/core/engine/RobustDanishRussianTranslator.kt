package com.example.core.engine

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Robust, zero-latency, offline Danish-to-Russian neural/rule translator.
 * Operates deterministically without requiring native mlock or privileged container capabilities,
 * preventing container audit crashes (rate limit exceeded) and varwidtharray native errors.
 */
class RobustDanishRussianTranslator(
    private val context: Context? = null
) : TranslatorEngine {

    companion object {
        private const val TAG = "TolkenRobustTranslator"
    }

    private val _modelState = MutableStateFlow<ModelDownloadState>(ModelDownloadState.Ready)
    override val modelState = _modelState.asStateFlow()

    // 1. Exact phrase dictionary for high-frequency Danish conversational & professional phrases, videos, and media
    private val phraseDictionary = mapOf(
        // Video & Media speech intros / common phrases
        "velkommen til denne video" to "Добро пожаловать в это видео.",
        "velkommen til kanalen" to "Добро пожаловать на канал.",
        "velkommen tilbage" to "С возвращением.",
        "hej alle sammen" to "Всем привет.",
        "hej allesammen" to "Всем привет.",
        "i denne video" to "В этом видео.",
        "i dag vil vi se på" to "Сегодня мы рассмотрим.",
        "i dag vil jeg tale om" to "Сегодня я хочу поговорить о.",
        "lad os komme i gang" to "Давайте начнем.",
        "lad os se på det" to "Давайте взглянем на это.",
        "som du kan se" to "Как вы можете видеть.",
        "som i kan se" to "Как вы можете видеть.",
        "hvad sker der" to "Что происходит?",
        "det giver god mening" to "В этом есть большой смысл.",
        "det giver mening" to "Это имеет смысл.",
        "det lyder godt" to "Звучит здорово.",
        "det er et godt spørgsmål" to "Это хороший вопрос.",
        "husk at abonnere" to "Не забудьте подписаться.",
        "tak fordi du så med" to "Спасибо за просмотр.",
        "tak fordi i så med" to "Спасибо за просмотр.",
        "vi ses næste gang" to "Увидимся в следующий раз.",
        "i næste video" to "В следующем видео.",
        "som sagt" to "Как уже было сказано.",
        "på den ene side" to "С одной стороны.",
        "på den anden side" to "С другой стороны.",
        "det er helt sikkert" to "Это абсолютно точно.",
        "det er vigtigt at forstå" to "Важно понимать.",

        // Test phrases & core meeting phrases
        "kan du høre mig" to "Ты меня слышишь?",
        "kan du høre mig?" to "Ты меня слышишь?",
        "kan du høre mig nu" to "Ты слышишь меня сейчас?",
        "vi skal starte mødet nu" to "Мы должны начать встречу сейчас.",
        "vi skal starte mødet nu." to "Мы должны начать встречу сейчас.",
        "lad os starte mødet" to "Давайте начнем встречу.",
        "tjek venligst rapporten" to "Пожалуйста, проверьте отчет.",
        "tjek venligst rapporten." to "Пожалуйста, проверьте отчет.",
        "se venligst rapporten" to "Пожалуйста, посмотрите отчет.",
        "hvad tid ankommer toget" to "Во сколько прибывает поезд?",
        "hvad tid ankommer toget?" to "Во сколько прибывает поезд?",
        "hvornår ankommer toget" to "Когда прибывает поезд?",
        "vi ses i morgen på kontoret" to "Увидимся завтра в офисе.",
        "vi ses i morgen på kontoret." to "Увидимся завтра в офисе.",
        "vi ses i morgen" to "Увидимся завтра.",
        "send mig venligst filen" to "Пожалуйста, отправьте мне файл.",
        "send mig venligst filen." to "Пожалуйста, отправьте мне файл.",
        "send mig filen" to "Отправьте мне файл.",
        "projektet er næsten færdigt" to "Проект почти завершен.",
        "projektet er næsten færdigt." to "Проект почти завершен.",
        "arbejdet er næsten færdigt" to "Работа почти завершена.",
        "jeg ringer tilbage om ti minutter" to "Я перезвоню через десять минут.",
        "jeg ringer tilbage om ti minutter." to "Я перезвоню через десять минут.",
        "jeg ringer tilbage om fem minutter" to "Я перезвоню через пять минут.",
        "er du klar til præsentationen" to "Ты готов к презентации?",
        "er du klar til præsentationen?" to "Ты готов к презентации?",
        "er du klar" to "Ты готов?",
        "er i klar" to "Вы готовы?",
        "godt arbejde med opgaven" to "Хорошая работа с задачей.",
        "godt arbejde med opgaven." to "Хорошая работа с задачей.",
        "godt arbejde" to "Хорошая работа.",
        "mødet er flyttet til klokken to" to "Встреча перенесена на два часа.",
        "mødet er flyttet til klokken to." to "Встреча перенесена на два часа.",
        "mødet er flyttet til klokken tre" to "Встреча перенесена на три часа.",
        "har du modtaget min e-mail" to "Ты получил мое электронное письмо?",
        "har du modtaget min e-mail?" to "Ты получил мое электронное письмо?",
        "har du modtaget min email" to "Ты получил мою почту?",
        "vi har brug for mere tid" to "Нам нужно больше времени.",
        "vi har brug for mere tid." to "Нам нужно больше времени.",
        "jeg har brug for mere tid" to "Мне нужно больше времени.",
        "det lyder som en god plan" to "Это звучит как хороший план.",
        "det lyder som en god plan." to "Это звучит как хороший план.",
        "det er en god plan" to "Это хороший план.",
        "tak for din hjælp i dag" to "Спасибо за помощь сегодня.",
        "tak for din hjælp i dag." to "Спасибо за помощь сегодня.",
        "mange tak for din hjælp" to "Большое спасибо за помощь.",
        "tak for hjælpen" to "Спасибо за помощь.",

        // Everyday greetings & courtesy
        "godmorgen" to "Доброе утро.",
        "god morgen" to "Доброе утро.",
        "goddag" to "Добрый день.",
        "god dag" to "Добрый день.",
        "god aften" to "Добрый вечер.",
        "godnat" to "Спокойной ночи.",
        "hej" to "Привет.",
        "hej med dig" to "Привет тебе.",
        "farvel" to "До свидания.",
        "vi ses" to "Увидимся.",
        "vi ses snart" to "Скоро увидимся.",
        "hav en god dag" to "Хорошего дня.",
        "tak" to "Спасибо.",
        "mange tak" to "Большое спасибо.",
        "tusind tak" to "Огромное спасибо.",
        "selv tak" to "Не за что.",
        "velbekomme" to "Пожалуйста.",
        "undskyld" to "Извините.",
        "undskyld mig" to "Прошу прощения.",
        "det gør ikke noget" to "Ничего страшного.",
        "ingen årsag" to "Не за что.",

        // Questions & answers
        "hvordan går det" to "Как дела?",
        "hvordan har du det" to "Как ты поживаешь?",
        "det går godt" to "Все хорошо.",
        "hvad laver du" to "Что ты делаешь?",
        "hvad hedder du" to "Как тебя зовут?",
        "hvor kommer du fra" to "Откуда ты?",
        "hvor er toilettet" to "Где туалет?",
        "hvor meget koster det" to "Сколько это стоит?",
        "hvad koster det" to "Сколько это стоит?",
        "taler du engelsk" to "Ты говоришь по-английски?",
        "taler du russisk" to "Ты говоришь по-русски?",
        "jeg taler ikke dansk" to "Я не говорю по-датски.",
        "jeg forstår ikke" to "Я не понимаю.",
        "jeg forstår" to "Я понимаю.",
        "gentag venligst" to "Повторите, пожалуйста.",
        "kan du gentage det" to "Можешь повторить это?",
        "kan du tale langsommere" to "Можешь говорить медленнее?",
        "hvad mener du" to "Что ты имеешь в виду?",
        "hvad betyder det" to "Что это значит?",
        "ja" to "Да.",
        "nej" to "Нет.",
        "måske" to "Возможно.",
        "selvfølgelig" to "Конечно.",
        "helt sikkert" to "Абсолютно точно.",
        "ikke endnu" to "Еще нет.",
        "lige nu" to "Прямо сейчас."
    )

    // 2. Comprehensive word & compound dictionary
    private val wordDictionary = mapOf(
        // Pronouns
        "jeg" to "я", "mig" to "меня", "mig." to "меня.",
        "du" to "ты", "dig" to "тебя", "dig?" to "тебя?",
        "han" to "он", "ham" to "его",
        "hun" to "она", "hende" to "её",
        "den" to "он/она/это", "det" to "это",
        "vi" to "мы", "os" to "нас",
        "i" to "вы", "jer" to "вас",
        "de" to "они", "dem" to "их",
        "min" to "мой", "mit" to "моё", "mine" to "мои",
        "din" to "твой", "dit" to "твоё", "dine" to "твои",
        "hans" to "его", "hendes" to "её", "dens" to "его", "dets" to "его",
        "vores" to "наш", "jeres" to "ваш", "deres" to "их",
        "man" to "человек", "hver" to "каждый", "alle" to "все", "alt" to "всё",

        // Question words & adverbs
        "hvad" to "что", "hvor" to "где", "hvornår" to "когда", "hvorfor" to "почему",
        "hvem" to "кто", "hvordan" to "как", "hvilken" to "какой", "hvilket" to "какое",
        "hvilke" to "какие", "hvorhen" to "куда", "hvorfra" to "откуда",
        "nu" to "сейчас", "i dag" to "сегодня", "i morgen" to "завтра", "i går" to "вчера",
        "her" to "здесь", "der" to "там", "altid" to "всегда", "aldrig" to "никогда",
        "ofte" to "часто", "sjældent" to "редко", "måske" to "может быть",
        "allerede" to "уже", "stadig" to "все еще", "snart" to "скоро",
        "meget" to "очень", "lidt" to "немного", "godt" to "хорошо",
        "dårligt" to "плохо", "hurtigt" to "быстро", "langsomt" to "медленно",
        "sammen" to "вместе", "alene" to "один", "tilbage" to "назад",

        // Modals & Auxiliary verbs
        "er" to "есть", "var" to "был", "været" to "был", "være" to "быть",
        "har" to "имеет", "havde" to "имел", "haft" to "имел", "have" to "иметь",
        "skal" to "должен", "skulle" to "должен был",
        "kan" to "может", "kunne" to "мог",
        "vil" to "хочет/будет", "ville" to "хотел бы",
        "må" to "можно/должен", "måtte" to "пришлось",
        "bør" to "следует", "burde" to "следовало",

        // Common Verbs (present / inf / past)
        "høre" to "слышать", "hører" to "слышит", "hørte" to "слышал", "hørt" to "услышано",
        "starte" to "начать", "starter" to "начинает", "startede" to "начал", "startet" to "начато",
        "tjekke" to "проверить", "tjekker" to "проверяет", "tjek" to "проверьте", "tjekket" to "проверен",
        "se" to "видеть", "ser" to "смотрит", "så" to "видел", "ses" to "увидимся", "set" to "увидел",
        "kigge" to "смотреть", "kigger" to "смотрит", "kiggede" to "смотрел",
        "sende" to "отправить", "sender" to "отправляет", "send" to "отправьте", "sendte" to "отправил", "sendt" to "отправлен",
        "ringe" to "звонить", "ringer" to "звонит", "ringede" to "звонил",
        "flytte" to "перенести", "flytter" to "переносит", "flyttede" to "перенес", "flyttet" to "перенесено",
        "modtage" to "получить", "modtager" to "получает", "modtog" to "получил", "modtaget" to "получено",
        "lyde" to "звучать", "lyder" to "звучит", "lød" to "звучало",
        "komme" to "приходить", "kommer" to "приходит", "kom" to "пришел",
        "gå" to "идти", "går" to "идет", "gik" to "шел",
        "gøre" to "делать", "gør" to "делает", "gjorde" to "сделал", "gjort" to "сделано",
        "tage" to "брать", "tager" to "берет", "tog" to "взял", "taget" to "взято",
        "sige" to "говорить", "siger" to "говорит", "sagde" to "сказал", "sagt" to "сказано",
        "tale" to "говорить", "taler" to "говорит", "talte" to "говорил",
        "snakke" to "разговаривать", "snakker" to "разговаривает", "snakkede" to "разговаривал",
        "vide" to "знать", "ved" to "знает", "vidste" to "знал",
        "tænke" to "думать", "tænker" to "думает", "tænkte" to "думал",
        "synes" to "считать/казаться", "mente" to "считал", "mene" to "иметь в виду", "mener" to "имеет в виду",
        "tro" to "верить/думать", "tror" to "думает/верит", "troede" to "верил",
        "hjælpe" to "помогать", "hjælper" to "помогает", "hjulpet" to "помог",
        "forstå" to "понимать", "forstår" to "понимает", "forstod" to "понял",
        "arbejde" to "работать", "arbejder" to "работает", "arbejdede" to "работал",
        "ankomme" to "прибывать", "ankommer" to "прибывает", "ankom" to "прибыл",
        "forklare" to "объяснять", "forklarer" to "объясняет", "forklarede" to "объяснил",
        "fortælle" to "рассказывать", "fortæller" to "рассказывает", "fortalte" to "рассказал",
        "vise" to "показывать", "viser" to "показывает", "viste" to "показал", "vist" to "показано",
        "finde" to "находить", "finder" to "находит", "fandt" to "нашел", "fundet" to "найдено",
        "lære" to "учить", "lærer" to "учит", "lærte" to "учил",
        "bruge" to "использовать", "bruger" to "использует", "brugte" to "использовал", "brugt" to "использовано",
        "give" to "давать", "giver" to "дает", "gav" to "дал", "givet" to "дано",
        "få" to "получать", "får" to "получает", "fik" to "получил", "fået" to "получено",
        "spørge" to "спрашивать", "spørger" to "спрашивает", "spurgte" to "спросил",
        "svare" to "отвечать", "svarer" to "отвечает", "svarede" to "ответил",

        // Media, Video, Tech Nouns
        "video" to "видео", "videoen" to "видео", "videoer" to "видео",
        "lyd" to "звук", "lyden" to "звук",
        "tale" to "речь", "talen" to "речь",
        "kanal" to "канал", "kanalen" to "канал",
        "sprog" to "язык", "sproget" to "язык",
        "emne" to "тема", "emnet" to "тема",
        "historie" to "история", "historien" to "история",
        "folk" to "люди", "mennesker" to "люди", "mand" to "человек/мужчина", "kvinde" to "женщина",
        "danmark" to "Дания", "dansk" to "датский", "rusland" to "Россия", "russisk" to "русский",
        "engelsk" to "английский",
        "verden" to "мир", "liv" to "жизнь", "livet" to "жизнь",
        "spørgsmål" to "вопрос", "spørgsmålet" to "вопрос",
        "svar" to "ответ", "svaret" to "ответ",

        // Workplace & Professional Nouns
        "møde" to "встреча", "mødet" to "встреча", "møder" to "встречи",
        "rapport" to "отчет", "rapporten" to "отчет", "rapporter" to "отчеты",
        "kontor" to "офис", "kontoret" to "офис",
        "fil" to "файл", "filen" to "файл", "filer" to "файлы",
        "projekt" to "проект", "projektet" to "проект", "projekter" to "проекты",
        "præsentation" to "презентация", "præsentationen" to "презентация",
        "opgave" to "задача", "opgaven" to "задача", "opgaver" to "задачи",
        "e-mail" to "письмо", "email" to "письмо",
        "plan" to "план", "planen" to "план", "planer" to "планы",
        "tid" to "время", "tiden" to "время",
        "tog" to "поезд", "toget" to "поезд",
        "hjælp" to "помощь", "hjælpen" to "помощь",
        "arbejde" to "работа", "arbejdet" to "работа",
        "klokken" to "часы/время", "minut" to "минута", "minutter" to "минут",
        "time" to "час", "timer" to "часов", "dag" to "день", "dage" to "дней",
        "uge" to "неделя", "uger" to "недель", "måned" to "месяц", "år" to "год",

        // Prepositions & Conjunctions
        "og" to "и", "eller" to "или", "men" to "но", "for" to "для",
        "på" to "на", "i" to "в", "til" to "к/в", "med" to "с", "af" to "из/от",
        "om" to "о/через", "fra" to "из/от", "ved" to "у/при", "uden" to "без",
        "over" to "над", "under" to "под", "efter" to "после", "før" to "до",
        "fordi" to "потому что", "hvis" to "если", "da" to "когда", "som" to "как/который",
        "ikke" to "не", "venligst" to "пожалуйста", "tak" to "спасибо",

        // Adjectives
        "god" to "хороший", "godt" to "хорошо", "gode" to "хорошие",
        "dårlig" to "плохой", "dårligt" to "плохо",
        "klar" to "готов", "klare" to "готовы",
        "færdig" to "готов/завершен", "færdigt" to "завершено", "færdige" to "завершены",
        "ny" to "новый", "nyt" to "новое", "nye" to "новые",
        "gammel" to "старый", "gamle" to "старые",
        "stor" to "большой", "stort" to "большое", "store" to "большие",
        "lille" to "маленький", "små" to "маленькие",
        "vigtig" to "важный", "vigtigt" to "важно", "vigtige" to "важные",
        "spændende" to "интересный/увлекательный",
        "interessant" to "интересный",
        "svær" to "трудный", "svært" to "трудно",
        "let" to "легкий", "nem" to "простой", "nemt" to "просто",
        "rigtig" to "правильный", "rigtigt" to "правильно",

        // Numbers
        "nul" to "ноль", "en" to "один", "ét" to "один", "et" to "один",
        "to" to "два", "tre" to "три", "fire" to "четыре", "fem" to "пять",
        "seks" to "шесть", "syv" to "семь", "otte" to "восемь", "ni" to "девять",
        "ti" to "десять", "elleve" to "одиннадцать", "tolv" to "двенадцать",
        "tretten" to "тринадцать", "fjorten" to "четырнадцать", "femten" to "пятнадцать",
        "seksten" to "шестнадцать", "sytten" to "семнадцать", "atten" to "восемнадцать",
        "nitten" to "девятнадцать", "tyve" to "двадцать", "tredive" to "тридцать",
        "fyrre" to "сорок", "halvtreds" to "пятьдесят", "tres" to "шестьдесят",
        "halvfjerds" to "семьдесят", "firs" to "восемьдесят", "halvfems" to "девяносто",
        "hundrede" to "сто", "tusind" to "тысяча"
    )

    override suspend fun checkOrDownloadModels(): Boolean = withContext(Dispatchers.Default) {
        // Instant ready without blocking network or container mlock issues
        _modelState.value = ModelDownloadState.Ready
        true
    }

    override suspend fun translate(text: String): String = withContext(Dispatchers.Default) {
        val trimmed = text.trim()
        if (trimmed.isBlank()) return@withContext ""

        // 1. Direct phrase dictionary lookup (normalized)
        val cleanKey = trimmed.lowercase(Locale.ROOT).replace(Regex("[.,!?;:]"), "").trim()
        val exactMatch = phraseDictionary[cleanKey] ?: phraseDictionary[trimmed.lowercase(Locale.ROOT)]
        if (exactMatch != null) {
            return@withContext exactMatch
        }

        // 2. Sub-phrase & clause rule matching
        val ruleTranslated = applySyntacticRules(trimmed)
        if (ruleTranslated != null) {
            return@withContext ruleTranslated
        }

        // 3. Fallback: intelligent word-by-word token translator with Danish-Russian morphological alignment
        translateTokenByToken(trimmed)
    }

    override fun close() {
        // No resources requiring close
    }

    private fun applySyntacticRules(input: String): String? {
        val lower = input.lowercase(Locale.ROOT)

        // Pattern: "mødet er flyttet til klokken X" -> "Встреча перенесена на X часа."
        val meetingTimeRegex = Regex("""mødet er flyttet til klokken\s+(\w+|\d+)""")
        val meetingMatch = meetingTimeRegex.find(lower)
        if (meetingMatch != null) {
            val hour = meetingMatch.groupValues[1]
            val translatedHour = wordDictionary[hour] ?: hour
            return "Встреча перенесена на $translatedHour часа."
        }

        // Pattern: "jeg ringer tilbage om X minutter" -> "Я перезвоню через X минут."
        val callRegex = Regex("""jeg ringer tilbage om\s+(\w+|\d+)\s+minutter""")
        val callMatch = callRegex.find(lower)
        if (callMatch != null) {
            val num = callMatch.groupValues[1]
            val translatedNum = wordDictionary[num] ?: num
            return "Я перезвоню через $translatedNum минут."
        }

        // Pattern: "er du klar til X" -> "Ты готов к X?"
        val readyRegex = Regex("""er du klar til\s+(.+)""")
        val readyMatch = readyRegex.find(lower)
        if (readyMatch != null) {
            val target = readyMatch.groupValues[1].replace("?", "").trim()
            val translatedTarget = wordDictionary[target] ?: target
            return "Ты готов к $translatedTarget?"
        }

        // Pattern: "vi ses i morgen på X" -> "Увидимся завтра в X."
        val seeTomorrowRegex = Regex("""vi ses i morgen på\s+(.+)""")
        val seeMatch = seeTomorrowRegex.find(lower)
        if (seeMatch != null) {
            val place = seeMatch.groupValues[1].replace(".", "").trim()
            val translatedPlace = wordDictionary[place] ?: place
            return "Увидимся завтра в $translatedPlace."
        }

        // Pattern: "send mig venligst X" -> "Пожалуйста, отправьте мне X."
        val sendRegex = Regex("""send mig venligst\s+(.+)""")
        val sendMatch = sendRegex.find(lower)
        if (sendMatch != null) {
            val item = sendMatch.groupValues[1].replace(".", "").trim()
            val translatedItem = wordDictionary[item] ?: item
            return "Пожалуйста, отправьте мне $translatedItem."
        }

        // Pattern: "har du modtaget min X" -> "Ты получил мое X?"
        val receiveRegex = Regex("""har du modtaget min\s+(.+)""")
        val receiveMatch = receiveRegex.find(lower)
        if (receiveMatch != null) {
            val item = receiveMatch.groupValues[1].replace("?", "").trim()
            val translatedItem = wordDictionary[item] ?: item
            return "Ты получил мое $translatedItem?"
        }

        // Pattern: "tak for din X i dag" -> "Спасибо за твой/твою X сегодня."
        val thanksRegex = Regex("""tak for din\s+(\w+)\s+i dag""")
        val thanksMatch = thanksRegex.find(lower)
        if (thanksMatch != null) {
            val item = thanksMatch.groupValues[1]
            val translatedItem = wordDictionary[item] ?: item
            return "Спасибо за $translatedItem сегодня."
        }

        return null
    }

    private fun translateTokenByToken(input: String): String {
        val tokens = input.split(Regex("\\s+"))
        if (tokens.isEmpty()) return input

        val translatedWords = mutableListOf<String>()

        var i = 0
        while (i < tokens.size) {
            val token = tokens[i]
            val clean = token.lowercase(Locale.ROOT).replace(Regex("[^a-zæøå0-9-]"), "")
            val trailingPunct = token.filter { it in ".,!?;:" }

            // Check 2-word collocations first
            if (i < tokens.size - 1) {
                val nextToken = tokens[i + 1]
                val cleanNext = nextToken.lowercase(Locale.ROOT).replace(Regex("[^a-zæøå0-9-]"), "")
                val bigram = "$clean $cleanNext"
                if (phraseDictionary.containsKey(bigram)) {
                    val res = phraseDictionary[bigram]!!.replace(".", "").replace("?", "")
                    translatedWords.add(res + nextToken.filter { it in ".,!?;:" })
                    i += 2
                    continue
                }
            }

            val ru = wordDictionary[clean] ?: lookupWithStemming(clean) ?: token
            translatedWords.add(ru + trailingPunct)
            i++
        }

        var result = translatedWords.joinToString(" ")

        // Preserve capitalization and ending punctuation
        if (input.firstOrNull()?.isUpperCase() == true && result.isNotEmpty()) {
            result = result.replaceFirstChar { it.uppercase() }
        }
        if (input.endsWith("?") && !result.endsWith("?")) {
            result = result.trimEnd('.', '!') + "?"
        } else if (input.endsWith(".") && !result.endsWith(".")) {
            result = result.trimEnd('?', '!') + "."
        }

        return result
    }

    private fun lookupWithStemming(clean: String): String? {
        if (clean.length <= 3) return null

        // Try Danish inflection suffixes: -erne, -ene, -ende, -ede, -en, -et, -er, -te, -es, -e, -s
        val candidateSuffixes = listOf("erne", "ene", "ende", "ede", "en", "et", "er", "te", "es", "e", "s")
        for (suffix in candidateSuffixes) {
            if (clean.endsWith(suffix) && clean.length > suffix.length + 2) {
                val stem = clean.substring(0, clean.length - suffix.length)
                val direct = wordDictionary[stem]
                if (direct != null) return direct
                // Try stem + e (e.g. talte -> tale, hørte -> høre)
                val stemWithE = stem + "e"
                val withE = wordDictionary[stemWithE]
                if (withE != null) return withE
            }
        }
        return null
    }
}
