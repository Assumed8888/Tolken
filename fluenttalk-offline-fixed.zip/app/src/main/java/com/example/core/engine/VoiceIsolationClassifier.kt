package com.example.core.engine

import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class SpeakerSource {
    SILENCE,
    INTERLOCUTOR_DANISH,
    USER_NEAR_FIELD,
    TTS_PLAYBACK_ECHO
}

/**
 * Intelligent acoustic & phonetic classifier that distinguishes
 * the external Danish interlocutor / video speech (da-DK) from the user's
 * own voice (near-field headset mic / Russian) and TTS audio playback.
 */
class VoiceIsolationClassifier(
    var ownVoiceThresholdDb: Float = 10.0f,
    var ownVoiceFilteringEnabled: Boolean = true,
    var echoGateTtsEnabled: Boolean = false,
    var cyrillicFilterEnabled: Boolean = true,
    var hangoverMs: Long = 400L
) {
    companion object {
        private const val TAG = "TolkenVoiceIsolation"
        private val CYRILLIC_REGEX = Regex("[\\p{IsCyrillic}]")
    }

    private val _currentSpeaker = MutableStateFlow(SpeakerSource.SILENCE)
    val currentSpeaker = _currentSpeaker.asStateFlow()

    private val _isUserSpeaking = MutableStateFlow(false)
    val isUserSpeaking = _isUserSpeaking.asStateFlow()

    private val _isInterlocutorSpeaking = MutableStateFlow(false)
    val isInterlocutorSpeaking = _isInterlocutorSpeaking.asStateFlow()

    private val _isAppHearingSound = MutableStateFlow(false)
    val isAppHearingSound = _isAppHearingSound.asStateFlow()

    private val _interlocutorRmsDb = MutableStateFlow(0f)
    val interlocutorRmsDb = _interlocutorRmsDb.asStateFlow()

    private val _userRmsDb = MutableStateFlow(0f)
    val userRmsDb = _userRmsDb.asStateFlow()

    private val _filteredClausesCount = MutableStateFlow(0)
    val filteredClausesCount = _filteredClausesCount.asStateFlow()

    @Volatile
    var isTtsCurrentlySpeaking: Boolean = false

    @Volatile
    private var lastUserVoiceDetectedMs: Long = 0L

    @Volatile
    private var lastCyrillicDetectedMs: Long = 0L

    @Volatile
    private var peakRmsInCurrentClause: Float = 0f

    @Synchronized
    fun onRmsChanged(rmsdB: Float) {
        val cleanRms = rmsdB.coerceAtLeast(0f)
        if (cleanRms > peakRmsInCurrentClause) {
            peakRmsInCurrentClause = cleanRms
        }

        val now = System.currentTimeMillis()
        val hasSound = cleanRms >= 0.3f
        _isAppHearingSound.value = hasSound

        when {
            // 1. TTS is speaking into earpiece: Echo gate active
            isTtsCurrentlySpeaking && echoGateTtsEnabled -> {
                _currentSpeaker.value = SpeakerSource.TTS_PLAYBACK_ECHO
                _isUserSpeaking.value = false
                _isInterlocutorSpeaking.value = false
                _interlocutorRmsDb.value = 0f
                _userRmsDb.value = 0f
            }

            // 2. High RMS surge or Cyrillic detected: Near-field user speech
            ownVoiceFilteringEnabled && (cleanRms >= ownVoiceThresholdDb || (now - lastCyrillicDetectedMs < 1800L)) -> {
                lastUserVoiceDetectedMs = now
                _currentSpeaker.value = SpeakerSource.USER_NEAR_FIELD
                _isUserSpeaking.value = true
                _isInterlocutorSpeaking.value = false
                _userRmsDb.value = cleanRms
                _interlocutorRmsDb.value = (_interlocutorRmsDb.value * 0.6f).coerceAtLeast(0f)
            }

            // 3. User voice hangover (trailing syllables right after user speech)
            ownVoiceFilteringEnabled && (now - lastUserVoiceDetectedMs < hangoverMs) -> {
                _currentSpeaker.value = SpeakerSource.USER_NEAR_FIELD
                _isUserSpeaking.value = true
                _isInterlocutorSpeaking.value = false
                _userRmsDb.value = cleanRms
                _interlocutorRmsDb.value = (_interlocutorRmsDb.value * 0.6f).coerceAtLeast(0f)
            }

            // 4. Acoustic energy from video or interlocutor: Danish speech sound!
            hasSound -> {
                _currentSpeaker.value = SpeakerSource.INTERLOCUTOR_DANISH
                _isInterlocutorSpeaking.value = true
                _isUserSpeaking.value = false
                _interlocutorRmsDb.value = cleanRms
                _userRmsDb.value = (_userRmsDb.value * 0.4f).coerceAtLeast(0f)
            }

            // 5. Silence / background noise
            else -> {
                _currentSpeaker.value = SpeakerSource.SILENCE
                _isInterlocutorSpeaking.value = false
                _isUserSpeaking.value = false
                _interlocutorRmsDb.value = (_interlocutorRmsDb.value * 0.5f).coerceAtLeast(0f)
                _userRmsDb.value = (_userRmsDb.value * 0.5f).coerceAtLeast(0f)
            }
        }
    }

    /**
     * Evaluates a recognized clause text and determines if it should be
     * suppressed/ignored as user self-speech or TTS echo.
     * Note: Danish speech from video or interlocutor must NEVER be suppressed!
     */
    @Synchronized
    fun evaluateClause(clauseText: String): Pair<Boolean, String?> {
        val now = System.currentTimeMillis()
        peakRmsInCurrentClause = 0f // Reset for next clause

        // Check 1: TTS Echo
        if (isTtsCurrentlySpeaking && echoGateTtsEnabled) {
            _filteredClausesCount.value += 1
            Log.i(TAG, "Suppressed clause as TTS Echo: '$clauseText'")
            return Pair(true, "Эхо воспроизведения TTS")
        }

        // Check 2: Cyrillic / Russian words spoken by user
        if (cyrillicFilterEnabled && containsCyrillic(clauseText)) {
            lastCyrillicDetectedMs = now
            lastUserVoiceDetectedMs = now
            _isUserSpeaking.value = true
            _filteredClausesCount.value += 1
            Log.i(TAG, "Suppressed clause containing Russian/Cyrillic speech: '$clauseText'")
            return Pair(true, "Русская речь владельца")
        }

        // Danish words / Latin speech from video or interlocutor is ALWAYS passed for translation
        return Pair(false, null)
    }

    private fun containsCyrillic(text: String): Boolean {
        return CYRILLIC_REGEX.containsMatchIn(text)
    }

    fun resetClauseRms() {
        peakRmsInCurrentClause = 0f
    }
}
