package com.example.core.engine

import android.content.Context
import android.util.Log
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeout
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Real on-device Danish -> Russian machine translation (Google ML Kit, pivots via English internally).
 * Models (~30 MB each) are downloaded once, after that translation works offline.
 * While the models are not ready (or on any failure) the built-in dictionary translator is used,
 * so the pipeline never stays silent.
 */
class MlKitDanishRussianTranslator(
    context: Context?,
    private val fallback: TranslatorEngine = RobustDanishRussianTranslator(context)
) : TranslatorEngine {

    companion object {
        private const val TAG = "TolkenMlKitTranslator"
        private const val TRANSLATE_TIMEOUT_MS = 5000L
    }

    private val translator: Translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.DANISH)
            .setTargetLanguage(TranslateLanguage.RUSSIAN)
            .build()
    )

    private val _modelState = MutableStateFlow<ModelDownloadState>(ModelDownloadState.NotDownloaded)
    override val modelState = _modelState.asStateFlow()

    @Volatile
    private var mlReady = false
    private val downloadMutex = Mutex()

    override suspend fun checkOrDownloadModels(): Boolean {
        if (mlReady) return true
        return downloadMutex.withLock {
            if (mlReady) {
                true
            } else {
                _modelState.value = ModelDownloadState.Downloading(0, "Загрузка модели da→ru (один раз, нужен интернет)…")
                try {
                    suspendCancellableCoroutine<Unit> { cont ->
                        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
                            .addOnSuccessListener { if (cont.isActive) cont.resume(Unit) }
                            .addOnFailureListener { if (cont.isActive) cont.resumeWithException(it) }
                    }
                    mlReady = true
                    _modelState.value = ModelDownloadState.Ready
                    Log.i(TAG, "ML Kit da->ru model ready")
                    true
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Log.w(TAG, "ML Kit model download failed", e)
                    _modelState.value = ModelDownloadState.Error(
                        "Модель не загружена (${e.message ?: "нет сети"}). Работает упрощённый словарь."
                    )
                    false
                }
            }
        }
    }

    override suspend fun translate(text: String): String {
        if (text.isBlank()) return ""
        if (!mlReady) return fallback.translate(text)
        return try {
            withTimeout(TRANSLATE_TIMEOUT_MS) {
                suspendCancellableCoroutine<String> { cont ->
                    translator.translate(text)
                        .addOnSuccessListener { if (cont.isActive) cont.resume(it) }
                        .addOnFailureListener { if (cont.isActive) cont.resumeWithException(it) }
                }
            }
        } catch (e: TimeoutCancellationException) {
            Log.w(TAG, "ML Kit translate timeout, using fallback")
            fallback.translate(text)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "ML Kit translate failed, using fallback", e)
            fallback.translate(text)
        }
    }

    override fun close() {
        try { translator.close() } catch (_: Exception) {}
        fallback.close()
    }
}
