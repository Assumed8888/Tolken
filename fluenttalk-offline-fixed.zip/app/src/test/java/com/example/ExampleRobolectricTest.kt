package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Tolken", appName)
  }

  @Test
  fun `test robust danish translator translates key test phrases`() = kotlinx.coroutines.runBlocking {
    val translator = com.example.core.engine.RobustDanishRussianTranslator()
    
    val p1 = translator.translate("Kan du høre mig?")
    assertEquals("Ты меня слышишь?", p1)

    val p2 = translator.translate("Vi skal starte mødet nu.")
    assertEquals("Мы должны начать встречу сейчас.", p2)

    val p3 = translator.translate("Tjek venligst rapporten.")
    assertEquals("Пожалуйста, проверьте отчет.", p3)

    val p4 = translator.translate("Vi ses i morgen på kontoret.")
    assertEquals("Увидимся завтра в офисе.", p4)

    val p5 = translator.translate("Tak for din hjælp i dag.")
    assertEquals("Спасибо за помощь сегодня.", p5)
  }
}
